package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Address;
import com.model.Person;

public class AddressDAO {
	private String jdbcURL;
    private String jdbcUsername;
    private String jdbcPassword;
    private Connection jdbcConnection;
    
    public AddressDAO(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }
     
    protected void connect() throws SQLException {
        if (jdbcConnection == null || jdbcConnection.isClosed()) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            jdbcConnection = DriverManager.getConnection(
                                        jdbcURL, jdbcUsername, jdbcPassword);
        }
    }
     
    protected void disconnect() throws SQLException {
        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
            jdbcConnection.close();
        }
    }
     
    public boolean insertAddress(Address address) throws SQLException {
        String sql = "INSERT INTO person (id, street, city, state, postalCode) VALUES (?, ?, ?,?,?)";
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, address.getId());
        statement.setString(2, address.getStreet());
        statement.setString(3, address.getCity());
        statement.setString(4, address.getState());
        statement.setString(5, address.getPostalCode());
         
        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowInserted;
    }
     
    public List<Address> listAllAddress() throws SQLException {
        List<Address> listAddress = new ArrayList<Address>();
         
        String sql = "SELECT * FROM Person";
         
        connect();
         
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String street = resultSet.getString("street");
            String city = resultSet.getString("city");
            String state = resultSet.getString("state");
            String postalCode = resultSet.getString("postalCode");
             
            Address address = new Address(id, street, city, state, postalCode);
            listAddress.add(address);
        }
         
        resultSet.close();
        statement.close();
         
        disconnect();
         
        return listAddress;
    }
     
    public boolean deleteAddress(Address address) throws SQLException {
        String sql = "DELETE FROM Person where id = ?";
         
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, address.getId());
         
        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowDeleted;     
    }
     
    public boolean updateAddressk(Address address) throws SQLException {
        String sql = "UPDATE Person SET title = ?, author = ?, price = ?";
        sql += " WHERE book_id = ?";
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, address.getId());
        statement.setString(2, address.getStreet());
        statement.setString(3, address.getCity());
        statement.setString(4, address.getState());
        statement.setString(5, address.getPostalCode());
         
        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowUpdated;     
    }
     
    public Address getAddress(int id) throws SQLException {
    	Address address = null;
        String sql = "SELECT * FROM Person WHERE id = ?";
         
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
         
        ResultSet resultSet = statement.executeQuery();
         
        if (resultSet.next()) {
             id = Integer.parseInt(resultSet.getString("id"));
            String street = resultSet.getString("street");
            String city = resultSet.getString("city");
            String state = resultSet.getString("state");
            String postalCode = resultSet.getString("postalCode");
             
            address = new Address(id, street, city, state, postalCode);
        }
         
        resultSet.close();
        statement.close();
         
        return address;
    }

}

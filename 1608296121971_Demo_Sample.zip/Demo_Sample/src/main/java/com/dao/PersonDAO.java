package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Person;

public class PersonDAO {

	 private String jdbcURL;
	    private String jdbcUsername;
	    private String jdbcPassword;
	    private Connection jdbcConnection;
	     
	    public PersonDAO(String jdbcURL, String jdbcUsername, String jdbcPassword) {
	        this.jdbcURL = jdbcURL;
	        this.jdbcUsername = jdbcUsername;
	        this.jdbcPassword = jdbcPassword;
	    }
	     
	    protected void connect() throws SQLException {
	        if (jdbcConnection == null || jdbcConnection.isClosed()) {
	            try {
	                Class.forName("com.mysql.jdbc.Driver");
	            } catch (ClassNotFoundException e) {
	                throw new SQLException(e);
	            }
	            jdbcConnection = DriverManager.getConnection(
	                                        jdbcURL, jdbcUsername, jdbcPassword);
	        }
	    }
	     
	    protected void disconnect() throws SQLException {
	        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
	            jdbcConnection.close();
	        }
	    }
	     
	    public boolean insertPerson(Person person) throws SQLException {
	        String sql = "INSERT INTO Person (id, firstName, lastName) VALUES (?, ?, ?)";
	        connect();
	         
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setLong(1, person.getId());
	        statement.setString(2, person.getFirstName());
	        statement.setString(3, person.getLastName());
	         
	        boolean rowInserted = statement.executeUpdate() > 0;
	        statement.close();
	        disconnect();
	        return rowInserted;
	    }
	     
	    public List<Person> listAllPersons() throws SQLException {
	        List<Person> listPersons = new ArrayList<Person>();
	         
	        String sql = "SELECT * FROM Person";
	         
	        connect();
	         
	        Statement statement = jdbcConnection.createStatement();
	        ResultSet resultSet = statement.executeQuery(sql);
	         
	        while (resultSet.next()) {
	            int id = resultSet.getInt("id");
	            String firstName = resultSet.getString("firstName");
	            String lastName = resultSet.getString("lastName");
	           
	             
	            Person person = new Person(id, firstName, lastName);
	            listPersons.add(person);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        disconnect();
	         
	        return listPersons;
	    }
	     
	    public boolean deletePerson(Person person) throws SQLException {
	        String sql = "DELETE FROM Person where id = ?";
	         
	        connect();
	         
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setInt(1, person.getId());
	         
	        boolean rowDeleted = statement.executeUpdate() > 0;
	        statement.close();
	        disconnect();
	        return rowDeleted;     
	    }
	     
	    public boolean updatePerson(Person person) throws SQLException {
	        String sql = "UPDATE Person SET id = ?, firstName = ?, lastName = ?";
	        sql += " WHERE id = ?";
	        connect();
	         
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setInt(1, person.getId());
	        statement.setString(2, person.getFirstName());
	        statement.setString(3, person.getLastName());
	      //  statement.setInt(4, book.getId());
	         
	        boolean rowUpdated = statement.executeUpdate() > 0;
	        statement.close();
	        disconnect();
	        return rowUpdated;     
	    }
	     
	    public Person getId(int id) throws SQLException {
	        Person person = null;
	        String sql = "SELECT * FROM Person WHERE id = ?";
	         
	        connect();
	         
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setInt(1, id);
	         
	        ResultSet resultSet = statement.executeQuery();
	         
	        if (resultSet.next()) {
	             id = resultSet.getInt("id");
	            String firstName = resultSet.getString("firstName");
	            String lastName = resultSet.getString("lastName");
	             
	            person = new Person(id,firstName,lastName);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        return person;
	    }
	}
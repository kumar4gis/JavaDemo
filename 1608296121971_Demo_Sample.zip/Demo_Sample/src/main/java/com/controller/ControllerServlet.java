package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.PersonDAO;
import com.model.Person;

public class ControllerServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
    private PersonDAO personDAO;
 
    public void init() {
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
 
        personDAO = new PersonDAO(jdbcURL, jdbcUsername, jdbcPassword);
 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
 
        try {
            switch (action) {
            case "/new":
                showNewForm(request, response);
                break;
            case "/insert":
                insertPerson(request, response);
                break;
            case "/delete":
                deletePerson(request, response);
                break;
            case "/edit":
                showEditForm(request, response);
                break;
            case "/update":
                updatePerson(request, response);
                break;
            default:
                listPerson(request, response);
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
 


	private void listPerson(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Person> listPerson = personDAO.listAllPersons();
        request.setAttribute("listPerson", listPerson);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ListPerson.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("PersonForm.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Person existingPerson = personDAO.getId(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("PersonForm.jsp");
        request.setAttribute("Person", existingPerson);
        dispatcher.forward(request, response);
 
    }
 
    @SuppressWarnings("unused")
	private void insertPerson(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer. parseInt(request.getParameter("id"));
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
 
        Person newPerson = new Person(id, firstName, lastName);
        personDAO.insertPerson(newPerson);
        response.sendRedirect("list");
    }
 
    private void updatePerson(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
 
        Person person = new Person(id, firstName, lastName);
        personDAO.updatePerson(person);
        response.sendRedirect("list");
    }
 
    private void deletePerson(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
 
        Person person = new Person(id);
        personDAO.deletePerson(person);
        response.sendRedirect("list");
 
    }
}

